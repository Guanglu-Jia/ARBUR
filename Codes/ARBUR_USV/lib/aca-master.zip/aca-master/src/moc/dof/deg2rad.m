function theta = deg2rad(omega)
% Transform degrees to radians.

theta = omega / 180 * pi;
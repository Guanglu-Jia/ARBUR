% function f = atof(a)
% String to float
%
% Input
%   a       -  string
%
% Output
%   f       -  float
%
% History
%   create  -  Feng Zhou (zhfe99@gmail.com), 01-29-2009
%   modify  -  Feng Zhou (zhfe99@gmail.com), 09-11-2009

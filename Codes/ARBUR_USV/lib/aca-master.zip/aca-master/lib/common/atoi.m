% function i = atoi(a)
% String to integer
%
% Input
%   a       -  string
%
% Output
%   i       -  integer
%
% History
%   create  -  Feng Zhou (zhfe99@gmail.com), 01-29-2009
%   modify  -  Feng Zhou (zhfe99@gmail.com), 09-11-2009
